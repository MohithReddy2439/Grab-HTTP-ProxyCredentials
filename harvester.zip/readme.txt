Thanks for checking out this(Dont forget to watch the video for better understanding)

Brief description about the things(Just How to install and use )
---------------------------------------------------------------
1.Run <./setup> from terminal in which you extracted the zip  as rooted user to configure the system so that  harvester works(Follow the instructions while running setup)
2.Now configuration is completed ,How to get credentials
a.run sudo harvester from your command line(you will get help message)
b.Suppose if I want to collect passes for 10.1.1.44:80,10.1.1.45:80,10.1.1.18:80,10.1.1.19:80 Run as following <sudo harvester 10.1.1.44 80 10.1.1.45 80 10.1.1.18 80 10.1.1.19 80>(it requires rooted permisions to run the command)
It scans the subnet and show you other nodes in your subnet(I did this with arp-scan )
Choose an IP address from list (arp-scan wont show correctly every time I recommend to manually check ip address wether that is reachable or not by ping)<refer video>
Enter your gateway<router address><refer video if you dont know what it is >
Enter your interface card name <eth0 enp2s0 genreally><refer video to find it out>
Enter the ip address of your interface card to find out its ip address from ifconfig <refer video>
What you have to do now is wait patiently
If victim starts browsing you will get the credentials
All incoming packets are logged by iptables so if you dont know what proxyserver client is using you can see the file /var/log/messages



Detailed description(if you are intersted to know how it works)
-------------------------------------------------------------

This is not at all possible with out two linux commands that are builtin (iptables,arpspoof)

1.arpspoof is used to redirect the packets towards your system which are actually intended to go to router (Actually by overwriting arptable entries of victim , packets come towards attacker )
2.Even though packets arrive these are discarded due to destination ip address , To overcome this iptables is used to overwrite the packets ipheader values (Exactly to say it overides the destination ip and destination port)<you can check it by (iptables -t nat -L -n -v) > command
3.Even though we redirected packets and change it destination to attacker ,unless we run a server we cant do the things ,That I accomplished with  C code

I know this is not detailed think it as detailed in breif 
		

							Thats it Exploit Network Traffic  :)))))
